import socket
dest = socket.gethostbyname(socket.gethostname())

IP = dest #pegando o IP dinamicamente
PORTA = 4455 #variavel porta
ADDR = (IP, PORTA)
TAMANHO = 1024
FORMATO = "utf-8"

def main(): #funcao main
    print("[STARTANDO] O servidor está startando")
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #utilizando conexão TCP
    server.bind(ADDR)
    server.listen()
    print("[FUNÇÃO LISTEN ESTÁ EM EXECUÇÃO]")

    while True:
        conn: socket
        conn, addr = server.accept()
        print(f"[NOVA CONEXÃO] {addr} conectado")
        filename = conn.recv(TAMANHO).decode(FORMATO)
        print("[RECEBIDO] O arquivo foi recebido.")
        file = open("arquivosServidor/" + filename, "w")
        conn.send("Arquivo recebido".encode(FORMATO))

        data = conn.recv(TAMANHO).decode(FORMATO)
        print(f"[RECEBIDO] Arquivo data foi recebido")
        file.write(data)
        conn.send("Arquivo foi recebido".encode(FORMATO))

        file.close()
        conn.close()

        print(f"[DESCONETADO] {addr} Desconectado ")
if __name__ == "__main__":
    main()