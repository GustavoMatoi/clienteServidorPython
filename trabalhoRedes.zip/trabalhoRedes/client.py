import socket #importando a biblioteca socket
import os
from datetime import date, datetime
import sys


IP = socket.gethostbyname(socket.gethostname()) #pegando o IP dinamicamente
PORTA = 4455 #variavel porta
ADDR = (IP, PORTA)
FORMATO = "utf-8"
TAMANHO = 1024

def main():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #mesmo protocolo que o servidor
    client.connect(ADDR)
    file = open("arquivosServidor/teste.txt", "r") #abrir o arquivo teste.txt e ler (r)
    data = file.read()
    client.send("teste.txt".encode(FORMATO))
    msg = client.recv(TAMANHO).decode(FORMATO)
    print(f"[SERVER]: {msg}")
    client.send(data.encode(FORMATO))
    msg = client.recv(TAMANHO).decode(FORMATO)
    print(f"[SERVER]: {msg}")
    parametros = []
    for parametro in sys.argv:
        if parametro != "client.py":
            parametros.append(parametro)

    client.close()
    data = date.today()
    ano = data.year
    mes = data.month
    dia = data.day
    horario = datetime.now()
    hora = horario.hour
    minutos = horario.minute
    segundos = horario.second
    arquivo = open('log.txt', 'w')



    i = " "
    while i != "sair":
        print("Escolha uma das opções")
        print("Listar arquivos")
        print("Escolher arquivo para download")
        print("Sair")

        i = input("Informe sua escolha ")

        if i == "listar":
            for i in os.listdir('arquivosServidor'):
                print(i)
            parametros.append("ls")
            arquivo.write("\n")
            arquivo.write(f'{dia}/{mes}/{ano} - {hora} : {minutos}: {segundos} - {parametros}')

        if i == "download":
            arquivoEscolhido = input("Qual arquivo deseja fazer o download?")
            parametros.append("download")
            parametros.append(arquivoEscolhido)
            arquivo.write("\n")
            arquivo.write(f'{dia}/{mes}/{ano} - {hora} : {minutos}: {segundos} - {parametros} ')
        if i == "sair":
            break



if __name__ == "__main__":
    main()